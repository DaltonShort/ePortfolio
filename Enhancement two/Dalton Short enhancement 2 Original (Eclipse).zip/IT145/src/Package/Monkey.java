package Package;

public class Monkey extends RescueAnimal {
	private double tailLength;
	private double height;
	private double bodyLength;
	private String species;
	
    // Constructor
	public Monkey () {}
    public Monkey(String name,String gender, String age,
    String weight, String acquisitionDate, String acquisitionCountry,
	String trainingStatus, boolean reserved, String inServiceCountry, double tailLength, double height, double bodyLength, 
	String species) {
        setName(name);
        setGender(gender);
        setAge(age);
        setWeight(weight);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);
    }
    //Accessors
    public double getTailLength() {
    	return tailLength;
    }
    public double getHeight() {
    	return height;
    }
    public double getBodyLength() {
    	return bodyLength;
    }
    public String getSpecies () {
    	return species;
    }
    //Mutators
    public void setTailLength (double mTailLength) {
    	tailLength = mTailLength;
    }
    public void setHeight (double mHeight) {
    	height = mHeight;
    }
    public void setBodyLength (double mBodyLength) {
    	bodyLength = mBodyLength;
    }
    public void setSpecies (String mSpecies) {
    	species = mSpecies;
    }
}
