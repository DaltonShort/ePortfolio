package Package;



import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Driver {
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();
    private static String menuInput = "Un-Assigned";
    // Instance variables (if needed)

    public static void main(String[] args) throws Exception {
    	Scanner scnr = new Scanner(System.in);


        initializeDogList();                                       // calls methods to make testing lists
        initializeMonkeyList();

        // Add a loop that displays the menu, accepts the users input
        // and takes the appropriate action.
	// For the project submission you must also include input validation
        // and appropriate feedback to the user.
        // Hint: create a Scanner and pass it to the necessary
        // methods 
	// Hint: Menu options 4, 5, and 6 should all connect to the printAnimals() method.
        do {
        		displayMenu();
        		System.out.println();
            	System.out.println("Enter menu input: ");
            	menuInput = scnr.nextLine();
        		if (menuInput.equals("1")) {
        			intakeNewDog(scnr);
        		} 
        		else if (menuInput.equals("2")) {
        			intakeNewMonkey(scnr);
        		}
        		else if (menuInput.equals("3")) {
        			reserveAnimal(scnr);
        		}
        		else if (menuInput.equals("4")) {
        			printAnimals("dog");
        		}
        		else if (menuInput.equals("5")) {
        			printAnimals("monkey");
        		}
        		else if (menuInput.equals("6")) {
        			printAnimals("available");
        		}
        		else if (menuInput.equalsIgnoreCase("q")) {
        			break;
        		}
        		else {
        			System.out.println("Invalid input Please enter 1, 2, 3, 4, 5, or 6");
        		}
        		
        	} 
        	while (menuInput != "quit");
        }


    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }


    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }


    // Adds monkeys to a list for testing
    //Optional for testing
    public static void initializeMonkeyList() {
        Monkey monkey1 = new Monkey("mSpot", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States", 0.0, 0.0, 0.0, "macaque");
        Monkey monkey2 = new Monkey("mRex", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States", 0.0, 0.0, 0.0, "macaque");
        Monkey monkey3 = new Monkey("mBella", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada", 0.0, 0.0, 0.0, "macaque");

        monkeyList.add(monkey1);
        monkeyList.add(monkey2);
        monkeyList.add(monkey3);
    }


    // Complete the intakeNewDog method
    // The input validation to check that the dog is not already in the list
    // is done for you
    public static void intakeNewDog(Scanner scanner) throws Exception {
    	boolean dogExists = false;
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        for(Dog dog: dogList) {
            if(dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system\n\n");          // check if dog already exists
                dogExists = true;
                return; //returns to menu
            }
        }
            try {
            if (dogExists = true) {
            	String gender = "NA";
            	String date;                                                              // collect information for the new dog
            	String checkReserve;
            	boolean reserved = false;
        		Scanner scnr = new Scanner(System.in);
        		
        		
            	System.out.println("Enter " + name + "'s breed: ");
            	String breed = scnr.nextLine();
            	System.out.println("Enter " + name + "'s gender: ");
            	gender = scnr.nextLine();
            	System.out.println("Enter " + name + "'s age");
            	String age = scnr.nextLine();
            	System.out.println("Enter " + name + "'s weight");
            	String weight = scnr.nextLine();
            	System.out.println("Enter " + name + "'s acquisition date: ");
				date = scnr.nextLine();
				System.out.println("Enter " + name + "'s acquisition country");
				String acquisitionCountry = scnr.nextLine();
				System.out.println("Enter " + name + "'s training status");
				String trainingStatus = scnr.nextLine();
				
				while (!trainingStatus.equalsIgnoreCase("yes") || !trainingStatus.equalsIgnoreCase("no")) {
					System.out.println("is " + name + " reserved? yes or no?");
					checkReserve = scnr.nextLine();
					
					
				if (checkReserve.equalsIgnoreCase("yes")) {                                                         // validate training status
						reserved = true;
						break;
						}
				else if (checkReserve.equalsIgnoreCase("no")) {
						reserved = false;
						break;
					}
				}
										
				System.out.println("Enter " + name + "'s in service country");
				String inServiceCountry = scnr.nextLine();
				
				
           		Dog newDog = new Dog();
				newDog.setName(name);
				newDog.setBreed(breed);
				newDog.setAcquisitionDate(date);
				newDog.setAge(age);
				newDog.setGender(gender);                                                                  // use class methods to set all the values
				newDog.setInServiceCountry(inServiceCountry);
				newDog.setTrainingStatus(trainingStatus);
				newDog.setWeight(weight);
				newDog.setAcquisitionLocation(acquisitionCountry);
				newDog.setReserved(reserved);
				dogList.add(newDog);
            }
            }
			    catch(InputMismatchException e) {}                                               // prevent termination of program by catching invalid inputs
				
				
				return;                                                                            // return to menu

            }
            	
         
        

        // Add the code to instantiate a new dog and add it to the appropriate list
    


        // Complete intakeNewMonkey
	//Instantiate and add the new monkey to the appropriate list
        // For the project submission you must also  validate the input
	// to make sure the monkey doesn't already exist and the species type is allowed
        public static void intakeNewMonkey(Scanner scanner) {
        	boolean monkeyExists = false;
        	System.out.println("What is the monkey's name?");
            String name = scanner.nextLine();
            for(Monkey monkey: monkeyList) {
                if(monkey.getName().equalsIgnoreCase(name)) {                                               // check if monkey already exists
                    System.out.println("\n\nThis monkey is already in our system\n\n");
                    monkeyExists = true;
                    return; //returns to menu
                }
            }
                if (monkeyExists = true) {
                	String date;
                	String checkReserve;
                	boolean reserved = false;
            		Scanner scnr = new Scanner(System.in);
                	try {
                		System.out.println("Enter " + name + "'s gender");
                		String gender = scnr.nextLine();
                		System.out.println("Enter " + name + "'s age");
                		String age = scnr.nextLine();
                		System.out.println("Enter " + name + "'s weight");                                      // prompt user for info
                		String weight = scnr.nextLine();
                		System.out.println("Enter " + name + "'s acquisition date: ");
    					date = scnr.nextLine();
    					System.out.println("Enter " + name + "'s acquisition country");
    					String acquisitionCountry = scnr.nextLine();
    					System.out.println("Enter " + name + "'s training status");
    					String trainingStatus = scnr.nextLine();
    					System.out.println("is " + name + " reserved? yes or no?");
    					checkReserve = scnr.nextLine();
    					
    					while (!reserved|| !reserved) {
    						System.out.println("is " + name + " reserved? yes or no?");
    						checkReserve = scnr.nextLine();
    					
    					if (checkReserve.equalsIgnoreCase("yes")) {
    							reserved = true;
    							break;
    						}
    					else if (checkReserve.equalsIgnoreCase("no")) {
    							reserved = false;
    							break;
    						}
    					}
    										
    					System.out.println("Enter " + name + "'s in service country");
    					String inServiceCountry = scnr.nextLine();
    					System.out.println("Enter " + name + "'s tail length");                                                      // 
    					double tailLength = scnr.nextDouble();
    					System.out.println("Enter " + name + "'s height");
    					double height = scnr.nextDouble();
    					System.out.println("Enter " + name + "'s body length");
    					double bodyLength = scnr.nextDouble();
    					
    					
    					
    					System.out.println("Enter " + name + "'s species");                                                          // get species and validate
    					String tempVar = scnr.nextLine();
    					String species = scnr.nextLine();
    					if ((species.equalsIgnoreCase("Capuchin")) || (species.equalsIgnoreCase("Macaque"))  || (species.equalsIgnoreCase("guenon"))
    							 || (species.equalsIgnoreCase("Marmoset")) || (species.equalsIgnoreCase("Squirrel monkey"))
    							 || (species.equalsIgnoreCase("tamarin"))) {
    						
    							}                                                                                                   
    					while (!((species.equalsIgnoreCase("Capuchin")) || (species.equalsIgnoreCase("Macaque"))  || (species.equalsIgnoreCase("guenon"))
   							 || (species.equalsIgnoreCase("Marmoset")) || (species.equalsIgnoreCase("Squirrel monkey"))
   							 || (species.equalsIgnoreCase("tamarin")))) {
    						System.out.println("Invalid monkey species");
    						species = scnr.nextLine();
    					}                                                                                                             // get species and validate
    						
    					
    					
    					
    					
    					
    					
    					
                		Monkey newMonkey = new Monkey();
                		newMonkey.setName(name);
                		newMonkey.setAcquisitionDate(date);
                		newMonkey.setAge(age);
                		newMonkey.setGender(gender);
                		newMonkey.setInServiceCountry(inServiceCountry);
                		newMonkey.setTrainingStatus(trainingStatus);
                		newMonkey.setWeight(weight);
                		newMonkey.setAcquisitionLocation(acquisitionCountry);
                		newMonkey.setReserved(reserved);
                		newMonkey.setTailLength(tailLength);                                       // set values
                		newMonkey.setHeight(height);
                		newMonkey.setBodyLength(bodyLength);
                		newMonkey.setSpecies(species);
    					monkeyList.add(newMonkey);
    					
                	}
                
        
                catch(InputMismatchException excpt) {}                                             // prevent termination
                	
                return;                                                                     // return to menu
                }
                }
             
        

        // Complete reserveAnimal
        // You will need to find the animal by animal type and in service country
        public static void reserveAnimal(Scanner scanner) {
        	Scanner scnr = new Scanner(System.in);
        	System.out.println("Enter animal's animal type");
        	String tempType = scnr.nextLine();                                                     // prompt for input
        	System.out.println("Enter animal's in service country");
        	String tempCountry = scnr.nextLine();
        	
        	if (tempType.equalsIgnoreCase("dog")) {
        		for(Dog dog: dogList) {
                    if(dog.getInServiceLocation().equalsIgnoreCase(tempCountry)) {                   // look through list for animal
                    	dog.setReserved(true);
                    	break;                                                                        // makes only the first instance reserve if multiple exist
                    }
            }
        	}
        	else if (tempType.equalsIgnoreCase("monkey")) {
        		for(Monkey monkey: monkeyList) {
                    if(monkey.getInServiceLocation().equalsIgnoreCase(tempCountry)) {                  // looks through list of animals if monkey
                    	monkey.setReserved(true);
                    }
            }
        	}
        }
        // Complete printAnimals
        // Include the animal name, status, acquisition country and if the animal is reserved.
	// Remember that this method connects to three different menu items.
        // The printAnimals() method has three different outputs
        // based on the listType parameter
        // dog - prints the list of dogs
        // monkey - prints the list of monkeys
        // available - prints a combined list of all animals that are
        // fully trained ("in service") but not reserved 
	// Remember that you only have to fully implement ONE of these lists. 
	// The other lists can have a print statement saying "This option needs to be implemented".
	// To score "exemplary" you must correctly implement the "available" list.
        public static void printAnimals(String x) {
        	if (x.equalsIgnoreCase("dog")) {
        	for(Dog dog: dogList) {
        		System.out.println(dog.getName() + " " + dog.getTrainingStatus() + " " + dog.getInServiceLocation() + " " + dog.getReserved());
        	}
        	}
        	if (x.equalsIgnoreCase("monkey")) {
        	for (Monkey monkey: monkeyList) {
        		System.out.println(monkey.getName() + " " + monkey.getTrainingStatus() + " " + monkey.getInServiceLocation() + " " + monkey.getReserved() 
        		+ " " + monkey.getSpecies());
        	}
        	}
        	if (x.equalsIgnoreCase("available")) {
        		for (Dog dog: dogList) {
        			if (dog.getTrainingStatus().equalsIgnoreCase("in service")) {
        				if (dog.getReserved()) {System.out.println(dog.getName() + " " + dog.getTrainingStatus() + " " + dog.getInServiceLocation() + " " + dog.getReserved());}
        			}
        		}
        		for (Monkey monkey:monkeyList) {
        			if (monkey.getTrainingStatus().equalsIgnoreCase("in service")) {
        				if (monkey.getReserved()) {System.out.println(monkey.getName() + " " + monkey.getTrainingStatus() + " " + monkey.getInServiceLocation() + " " + monkey.getReserved());}
        			}
        		}
        	}
}
}

