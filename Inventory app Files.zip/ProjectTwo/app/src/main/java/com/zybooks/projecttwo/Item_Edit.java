package com.zybooks.projecttwo;

import static java.sql.Types.NULL;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import com.zybooks.projecttwo.data.UserRepository;

public class Item_Edit extends AppCompatActivity {
    private EditText newCount;

    UserRepository userRepository = new UserRepository(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_edit); // Set the layout for this activity
        EdgeToEdge.enable(this);

        newCount = findViewById(R.id.countUpdate);
        String itemName = getIntent().getStringExtra("itemName");

        Button editButton = findViewById(R.id.SubmitButton);
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String countText = newCount.getText().toString();
                if (countText.isEmpty()) {
                    // Show a toast message or handle the empty input as needed
                    Toast.makeText(Item_Edit.this, "Please enter a valid count", Toast.LENGTH_SHORT).show();
                } else {
                    int newQuant = Integer.parseInt(countText);
                    if (newQuant < 0) {
                        // Handle the case where the input count is not valid (e.g., less to 0)
                        Toast.makeText(Item_Edit.this, "Please enter a positive count", Toast.LENGTH_SHORT).show();
                    } else {
                        userRepository.updateItemQuantity(itemName, newQuant);

                        Intent intent = new Intent(Item_Edit.this, Inventory_grid.class);
                        startActivity(intent);
                    }
                }
            }
        });

        Button cancelButton = findViewById(R.id.cancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Item_Edit.this, Inventory_grid.class);
                startActivity(intent);
            }
        });
    }
}
