package com.zybooks.projecttwo;

import static androidx.core.content.ContentProviderCompat.requireContext;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.projecttwo.data.UserRepository;
import com.zybooks.projecttwo.db.Helper;
import com.zybooks.projecttwo.db.UserContract;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Inventory_grid extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_grid); // Set the layout for this activity
        EdgeToEdge.enable(this);

        // Set up recycler view
        UserRepository UserRepository = new UserRepository(this);
        Helper helper = new Helper(this);

        List<Item> itemlist = getItemsFromDatabase();

        RecyclerView recyclerview = findViewById(R.id.InventoryList);
        recyclerview.setLayoutManager(new LinearLayoutManager(this));

        ItemAdapter itemadapter = new ItemAdapter(this, itemlist);
        recyclerview.setAdapter(itemadapter);


        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Inventory_grid.this, item_add.class);
                startActivity(intent);
            }
        });

        Button permissions = findViewById(R.id.permissions);
        permissions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Inventory_grid.this, Permissions.class);
                startActivity(intent);
            }
        });
    }


    private void checkAndSendLowQuantityWarning(String itemName, int itemCount) {
        // Get phone number variable
        Intent intent = getIntent();
        String phoneNumber = intent.getStringExtra("phoneNumber");

        if (itemCount < 5) {
            String message = "Warning: Item " + itemName + " is running low. Current count: " + itemCount;
            sendSMS(phoneNumber, message); // Replace "+1234567890" with the recipient's phone number
            Toast.makeText(this, "Low quantity warning sent for " + itemName, Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSMS(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        } catch (Exception e) {
            Toast.makeText(this, "SMS sending failed", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    Helper helper = new Helper(this);
    private List<Item> getItemsFromDatabase() {
        List<Item> items = new ArrayList<>();
        Map<String, Integer> itemMap = helper.getAllItemNamesAndCountsFromDatabase(this);

        for (Map.Entry<String, Integer> entry : itemMap.entrySet()) {
            items.add(new Item(entry.getKey(), entry.getValue()));
        }

        return items;
    }
    private void editItem(String itemName) {
        Intent intent = new Intent(Inventory_grid.this, Item_Edit.class);
        intent.putExtra("itemName", itemName);
        startActivity(intent);
    }

}
