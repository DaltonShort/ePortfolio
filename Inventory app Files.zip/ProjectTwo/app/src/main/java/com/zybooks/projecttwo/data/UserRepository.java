package com.zybooks.projecttwo.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.zybooks.projecttwo.db.Helper;
import com.zybooks.projecttwo.db.UserContract;

public class UserRepository {
    private Helper dbHelper;

    // Constructor initializing the Helper object
    public UserRepository(Context context) {
        dbHelper = new Helper(context);
    }

    // Method to add a new user to the database
    public long addUser(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Create ContentValues object to hold user data
        ContentValues values = new ContentValues();
        values.put(UserContract.UserEntry.COLUMN_USERNAME, username);
        values.put(UserContract.UserEntry.COLUMN_PASSWORD, password);

        long newRowId = db.insert(UserContract.UserEntry.TABLE_NAME, null, values);

        db.close();
        return newRowId;
    }

    public void addItem(String itemName, int itemCount) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserContract.ItemGrid.COLUMN_ITEMNAME, itemName);
        values.put(UserContract.ItemGrid.COLUMN_ITEMCOUNT, itemCount);

        Log.d("UserRepository", "Adding item: " + itemName + ", Count: " + itemCount);

        long newRowId = db.insert(UserContract.ItemGrid.TABLE_NAME, null, values);
        if (newRowId == -1) {
            Log.e("UserRepository", "Error inserting item: " + itemName);
        } else {
            Log.d("UserRepository", "Item inserted successfully, Row ID: " + newRowId);
        }

        db.close();
    }

    public void deleteItem(String itemName) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        // Define the selection criteria
        String selection = UserContract.ItemGrid.COLUMN_ITEMNAME + " = ?";
        String[] selectionArgs = { itemName };

        // Perform the delete operation
        int deletedRows = db.delete(UserContract.ItemGrid.TABLE_NAME, selection, selectionArgs);

        // Close the database
        db.close();
    }

    public void updateItemQuantity(String itemName, int newQuantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // New value for the item count column
        ContentValues values = new ContentValues();
        values.put(UserContract.ItemGrid.COLUMN_ITEMCOUNT, newQuantity);

        // Define the selection criteria
        String selection = UserContract.ItemGrid.COLUMN_ITEMNAME + " = ?";
        String[] selectionArgs = { itemName };

        // Perform the update operation
        int updatedRows = db.update(UserContract.ItemGrid.TABLE_NAME, values, selection, selectionArgs);

        // Close the database
        db.close();
    }
}
