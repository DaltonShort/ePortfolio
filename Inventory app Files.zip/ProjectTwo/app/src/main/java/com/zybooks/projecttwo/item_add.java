package com.zybooks.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.projecttwo.data.UserRepository;

public class item_add extends AppCompatActivity {
    private EditText itemNameEditText;
    private EditText itemQuantityEditText;

    // Create an instance of UserRepository
    UserRepository userRepository = new UserRepository(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_add); // Set the layout for this activity
        EdgeToEdge.enable(this);

        itemNameEditText = findViewById(R.id.itemNameText);
        itemQuantityEditText = findViewById(R.id.itemQuantityText);

        Button cancelButton = findViewById(R.id.cancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(item_add.this, Inventory_grid.class);
                startActivity(intent);
            }
        });

        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userRepository.addItem(itemNameEditText.getText().toString(), Integer.parseInt(itemQuantityEditText.getText().toString()));
                Intent intent = new Intent(item_add.this, Inventory_grid.class);
                startActivity(intent);
            }
        });
    }
}
