package com.zybooks.projecttwo;


import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.zybooks.projecttwo.R;
import com.zybooks.projecttwo.Item;
import com.zybooks.projecttwo.data.UserRepository;

import java.util.List;
import android.content.Context;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private List<Item> itemList;
    private Context context;

    public ItemAdapter(Context context, List<Item> itemList) {

        this.itemList = itemList;
        this.context = context;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_list_recycler, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item currentItem = itemList.get(position);
        holder.itemName.setText(currentItem.getItemName());
        holder.itemCount.setText(String.valueOf(currentItem.getItemCount()));

        // Handle button clicks
        holder.button1.setOnClickListener(v -> {
            // Create an Intent to open Item_Edit activity
            Intent intent = new Intent(context, Item_Edit.class);
            // Pass the item name to the Item_Edit activity
            intent.putExtra("itemName", currentItem.getItemName());
            context.startActivity(intent);
        });


        holder.button2.setOnClickListener(v -> {
            String itemName = currentItem.getItemName();
            deleteItemFromDatabase(itemName, holder.getAdapterPosition());
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        public TextView itemName;
        public TextView itemCount;
        public Button button1;
        public Button button2;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.item_name);
            itemCount = itemView.findViewById(R.id.item_count);
            button1 = itemView.findViewById(R.id.button1);
            button2 = itemView.findViewById(R.id.Delete);
        }
    }

    private void deleteItemFromDatabase(String itemName, int position) {
        UserRepository userRepository = new UserRepository(context);
        userRepository.deleteItem(itemName);

        // Remove the item from the list and notify the adapter
        itemList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, itemList.size());

        Toast.makeText(context, "Item deleted successfully", Toast.LENGTH_SHORT).show();
    }
}