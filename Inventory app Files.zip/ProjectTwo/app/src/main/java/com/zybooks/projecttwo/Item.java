package com.zybooks.projecttwo;

public class Item {

    private String itemName;
    private int itemCount;

    public Item(String itemName, int itemCount) {
        this.itemName = itemName;
        this.itemCount = itemCount;
    }

    public String getItemName (){
        return itemName;
    }
    public  int getItemCount(){
        return itemCount;
    }
}
